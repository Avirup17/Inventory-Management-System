const exp=require("express")
const bcrypt=require("bcrypt");
const router=exp.Router();
const User=require("../model/user");
  router.post("/reg",async(req,res)=>{

    var salt=await bcrypt.genSalt(10);
    const hp=await bcrypt.hash(req.body.pass,salt);

    var insobj={
        name:req.body.name,
        email:req.body.email,
        password:hp,

    };

    await User.create(insobj);
    var resdata={
        msg:"success"
    };

    res.json(resdata)
  });

module.exports=router;