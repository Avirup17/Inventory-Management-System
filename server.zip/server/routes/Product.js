const exp=require("express");
const router=exp.Router();
const product=require("../model/product");
const fs=require("fs");

router.post("/add",async(req,res)=>{

    console.log(req.body);
    var imgobj=req.files.pimg;

    imgobj.mv("./public/product_img/"+imgobj.name,async(err)=>{
        if(err){
            throw err;
        }

        var ins={
            Product_Name:req.body.Name,
            Product_Price:req.body.Price,
            Product_Image:imgobj.name
        };
        await product.create(ins);
    })

    var resdata={msg:"Form Submitted"};
    res.json(resdata);
});

router.get("/sel",async(req,res)=>{

    var pdata=await product.find();
    res.json(pdata);
});

router.post("/del",async(req,res)=>{

    var id=req.body.id;
    var pdata=await product.findById(id);

    fs.unlinkSync("./public/product_img/"+pdata.Product_Image);
    await product.findByIdAndDelete(id);

    var resdata={msg:"Record Deleted"};
    res.json(resdata);
});

module.exports=router;