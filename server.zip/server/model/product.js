const mongoose=require("mongoose");
const pschema=mongoose.Schema({
    Product_Name:String,
    Product_Price:Number,
    Product_Image:String
});

module.exports=mongoose.model("Products",pschema);