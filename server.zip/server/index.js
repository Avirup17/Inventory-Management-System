const exp=require("express");
const app=exp();
const cors=require("cors");
const bodyParser=require("body-parser")
const expressfileupload=require("express-fileupload");
const mongoose = require('mongoose');
mongoose.connect('mongodb+srv://iemnode:n123456@cluster0.a3eltkd.mongodb.net/mydatabase?retryWrites=true&w=majority');

app.use(cors());
app.use(expressfileupload());
app.use(exp.static('public'))

app.use(bodyParser.urlencoded({ extended: false }))
app.use(bodyParser.json())

app.get("/",(req,res)=>{
    res.send("Hello Node")
})

const pr=require("./routes/Product");
const au=require("./routes/auth")

app.use("/product",pr);
app.use("/auth",au);


app.listen(2000);