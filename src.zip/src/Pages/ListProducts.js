import Menu from "../Inc/Menu";
import Top from "../Inc/Topbar";
import Footer from "../Inc/Footer";
import { useEffect,useState } from "react";

function ListProducts() {

    let[Products,setProducts]=useState([]);

    async function getdata(){
        var response=await fetch("http://localhost:2000/product/sel");
        var data=await response.json();
        console.log(data);
        setProducts(data);
    }

    useEffect(()=>{
        getdata()
    },[])

    return (
      <>     
<div>
  <div id="wrapper">
    {/* Sidebar */}
    <Menu/>
    {/* End of Sidebar */}
    {/* Content Wrapper */}
    <div id="content-wrapper" className="d-flex flex-column">
      {/* Main Content */}
      <div id="content">
        {/* Topbar */}
         <Top/>
        {/* End of Topbar */}
        {/* Begin Page Content */}
        <div className="container-fluid">
          {/* Page Heading */}
          <h1 className="h3 mb-4 text-gray-800">List Products</h1>

          <table className="table">
    <thead>
      <tr>
        <th>Product Name</th>
        <th>Product Price</th>
        <th>Product Image</th>
        <th>Delete Product</th>
      </tr>
    </thead>
    <tbody>
      {Products.map((p)=>
        <tr key={p._id}>

            <td>{p.Product_Name}</td>
            <td>{p.Product_Price}</td>
            <td><img className="psize" src={"http://localhost:2000/product_img/"+p.Product_Image}/></td>
            <td><button className="btn btn-danger" onClick={async()=>{

               if(window.confirm("Are you sure?")){
              var fd=new FormData();
              fd.append("id",p._id);

              var resp=await fetch("http://localhost:2000/product/del",{
                method: 'POST',
                body:fd
              });
              var data=await resp.json();
              
              
              getdata();
              
            }}}>Delete</button></td>

        </tr>
      )}
    </tbody>
  </table>
        </div>
        {/* /.container-fluid */}
      </div>
      {/* End of Main Content */}
      {/* Footer */}
        <Footer/>
      {/* End of Footer */}
    </div>
    {/* End of Content Wrapper */}
  </div>
  {/* End of Page Wrapper */}
  {/* Scroll to Top Button*/}
  <a className="scroll-to-top rounded" href="#page-top">
    <i className="fas fa-angle-up" />
  </a>
  {/* Logout Modal*/}
  
</div>

      </>
    );
  }
  
  export default ListProducts;