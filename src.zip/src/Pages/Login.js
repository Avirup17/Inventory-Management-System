import Menu from "../Inc/Menu";
import Top from "../Inc/Topbar";
import Footer from "../Inc/Footer";
import { useState } from "react";
import { useNavigate } from "react-router-dom";

function Login() {

const navi=useNavigate();

let[email,setemail]=useState("");
let[pass,setpass]=useState("");


    return ( 
    <>
          <h1 className="h3 mb-4 text-gray-800">Sign in</h1>

            <p>Email</p>
          <p><input type="email" onChange={(ev)=>{
            setemail(ev.target.value);
          }}/></p>

        <p>Pasword</p>
          <p><input type="text" onChange={(ev)=>{
            setpass(ev.target.value);
          }}/>
          </p>
          <p>
            <button classname='btn btn-success' onClick={async()=>{


              var fd=new FormData();
              
              fd.append("email",email);
              fd.append("pass",pass);

              var resp=await fetch("http://localhost:2000/auth/reg",{
                method:'POST',
                body:fd
            });
            var data=await resp.json();
            console.log(data);


            }}>Sign In</button>
          </p>

      </>
    );
  }
  
export default Login;