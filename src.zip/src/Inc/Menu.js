import { NavLink } from "react-router-dom";

function Menu() {
  return (<><ul className="navbar-nav bg-gradient-primary sidebar sidebar-dark accordion" id="accordionSidebar">
    <NavLink className="sidebar-brand d-flex align-items-center justify-content-center" to="index.html">
      <div className="sidebar-brand-icon rotate-n-15">
        <i className="fas fa-laugh-wink" />
      </div>
      <div className="sidebar-brand-text mx-3">SB Admin <sup>2</sup></div>
    </NavLink>
    <hr className="sidebar-divider my-0" />
    <li className="nav-item">
      <NavLink className="nav-link" to="/Dashboard">
        <i className="fas fa-fw fa-tachometer-alt" />
        <span>Dashboard</span></NavLink>
    </li>
    <hr className="sidebar-divider" />
    <div className="sidebar-heading">
      Interface
    </div>
    <li className="nav-item">
      <NavLink className="nav-link collapsed" to="#" data-toggle="collapse" data-target="#collapseTwo" aria-expanded="true" aria-controls="collapseTwo">
        <i className="fas fa-fw fa-cog" />
        <span>Manage Products</span>
      </NavLink>
      <div id="collapseTwo" className="collapse" aria-labelledby="headingTwo" data-parent="#accordionSidebar">
        <div className="bg-white py-2 collapse-inner rounded">
          <NavLink className="collapse-item" to="/Add-Product">Add Product</NavLink>
          <NavLink className="collapse-item" to="/ListProducts">List Products</NavLink>
        </div>
      </div>
    </li>
  </ul>
  </>
  );
}

export default Menu;