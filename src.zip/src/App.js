import './App.css';
import {BrowserRouter,Routes,Route} from 'react-router-dom';
import Home from './Pages/Home';
import Dashboard from './Pages/Dashboard';
import AddProduct from './Pages/AddProduct';
import ListProducts from './Pages/ListProducts';
import Signup from './Pages/signup';
import Login from './Pages/Login';

function App() {
  return (
    <>
    <BrowserRouter>
    <Routes>
      <Route path='/' element={<Home/>} />
      <Route path='/Add-Product' element={<AddProduct/>} />
      <Route path='/Dashboard' element={<Dashboard/>} />
      <Route path='/ListProducts' element={<ListProducts/>} />
      <Route path='/signup' element={<Signup/>} />
      <Route path='/Login' element={<Login/>} />
    </Routes>
    </BrowserRouter>
    </>
  );
}

export default App;
